extern crate reqwest;
extern crate atoi;
extern crate rand;

pub mod random;

#[cfg(test)]
mod tests {
    #[test]
    fn it_works() {
        assert_eq!(2 + 2, 4);
    }
}
